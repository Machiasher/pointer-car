package com.company;

public class Car {
    private String colour;
    private String brandName;
    double fuelAmount;
    double mileage;
    double fuelConsumption;
    //Написати метод: void drive(int km) — потрібно розрахувати чи вистачить пального на поїздку по заданим даним,
    // якщо вистачить вивести скільки машина проїхала і загальний пробіг, якщо не вистачить — вивести порахувати
    // і вивести скільки машина змогла проїхати і загальний пробіг, якщо пального не має вивести повідомлення
    // про необхідність заправити машину. В перших 2-х випадках зменшити обʼєм пального на величину яка залежить
    // від заданої довжини поїздки і розходу пального. Написати метод: void reFuel(int fuelVolume). Написати метод:
    // void distance() який виводить данні про машину і пробіг.
    // Можна дописати машині любі необхідні поля, а також будь-яку кількість конструкторів.


    public Car(String colour, String brandName, double fuelAmount, double mileage, double fuelConsumption) {
        this.colour = colour;
        this.brandName = brandName;
        this.fuelAmount = fuelAmount;
        this.mileage = mileage;
        this.fuelConsumption = fuelConsumption;
    }

    public void drive() {
        double approximatelyMileage = (fuelAmount / fuelConsumption) * 100;
        double trueMileage = approximatelyMileage + mileage;
        if (approximatelyMileage > mileage * 2) {
            System.out.println("Машина проїхала" + " " + approximatelyMileage + " " + "Сумарний пробіг -" + " " + trueMileage);
        } else if (approximatelyMileage < mileage * 2) {
            double mileageR = (fuelAmount / fuelConsumption) * 100;
            System.out.println("Машина проїхала" + " " + mileageR + " " + "Сумарний пробіг -" + " " + trueMileage);
        }
        else{
            System.out.println("Перевірь рівень пального, його не вистачає!");
        }
    }
}