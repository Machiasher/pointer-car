package com.company;

public class Main {


    public static void main(String[] args) {

        Car car1 = new Car("Black","Mercedes", 64.50, 2300, 9.6);
        Car car2 = new Car("Black","Audi", 30.0, 5755, 9.6);
        Car car3 = new Car("Black","BMW", 0, 12324, 9.6);

        car1.drive();
        car2.drive();
        car3.drive();
    }
}
